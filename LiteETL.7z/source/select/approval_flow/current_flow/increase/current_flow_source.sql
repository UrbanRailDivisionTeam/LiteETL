SELECT
    bill.fid as "id",
    bill.fmodifydate as "修改时间"
FROM
    crrc_wfs.T_WF_EXECUTION bill