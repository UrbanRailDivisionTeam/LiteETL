SELECT
    bill.fid as "id",
    bill.FMODIFYDATE as "修改时间"
FROM
    crrc_sys.t_meta_entitydesign bill