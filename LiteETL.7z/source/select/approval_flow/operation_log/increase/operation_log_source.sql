SELECT
    bill.fid as "id",
    bill.fmodifydate as "修改日期"
FROM
    crrc_wfs.t_wf_operationlog bill