SELECT
    bill."id",
    bill."修改日期"
FROM
    ods.af_operation_log bill