SELECT
    bill."id",
    bill."时间"
FROM
    ods.online_worktime bill