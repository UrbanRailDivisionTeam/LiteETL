SELECT
    bill."id",
    bill."修改日期"
FROM
    ods.temp_worktime bill