SELECT
    bill."id",
    bill."题案状态",
    bill."提交日期"
FROM
    ods.ameliorate bill