select
    bill."id",
    bill."修改时间",
    bill."单据状态"
FROM
    ods.alignment_error_handle bill