SELECT
    bill."id",
    bill."修改时间"
FROM
    ods.wire_number_entry bill