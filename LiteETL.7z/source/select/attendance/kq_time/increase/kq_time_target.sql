SELECT
    bill."id",
    bill."调整时间"
FROM
    ods.attendance_kq_time bill