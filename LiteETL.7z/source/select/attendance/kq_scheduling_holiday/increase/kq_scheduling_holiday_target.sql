SELECT 
    bill."id",
    bill."对应调整(换休)日期"
FROM ods.attendance_kq_scheduling_holiday bill