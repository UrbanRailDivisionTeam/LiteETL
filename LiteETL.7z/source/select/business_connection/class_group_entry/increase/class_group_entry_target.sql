SELECT
    bill."id",
    bill."单据头修改时间"
FROM
    ods.class_group_entry bill