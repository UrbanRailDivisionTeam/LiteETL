SELECT
    bill."id",
    bill."经办日期"
FROM
    ods.shop_execution_handle bill