SELECT
    bill."id",
    bill."修改时间"
FROM
    ods.class_group bill