SELECT
    bill.FID AS "id",
    bill.fmodifytime AS "修改时间"
FROM
    crrc_secd.tk_crrc_classgroup bill