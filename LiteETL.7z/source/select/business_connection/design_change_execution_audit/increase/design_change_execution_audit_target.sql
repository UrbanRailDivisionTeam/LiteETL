SELECT
    bill."id",
    bill."审核日期"
FROM
    ods.design_change_execution_audit bill