SELECT
    bill."id",
    bill."修改时间",
    bill."发放日期"
FROM
    ods.design_change_entry bill