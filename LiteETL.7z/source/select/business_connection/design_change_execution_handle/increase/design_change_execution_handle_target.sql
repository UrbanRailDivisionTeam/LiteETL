SELECT
    bill."id",
    bill."经办日期"
FROM
    ods.design_change_execution_handle bill