SELECT
    bill."id",
    bill."审核日期"
FROM
    ods.shop_execution_audit bill