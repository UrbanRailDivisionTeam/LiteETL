SELECT
    bill."id",
    bill."修改时间"
FROM
    ods.design_change_execution_change_content bill