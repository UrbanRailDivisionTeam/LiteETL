SELECT
    bill.FId AS "id",
    bill.fmodifytime AS "修改时间",
    bill.fauditdate AS "批准时间"
FROM
    crrc_secd.tk_crrc_chgbill bill