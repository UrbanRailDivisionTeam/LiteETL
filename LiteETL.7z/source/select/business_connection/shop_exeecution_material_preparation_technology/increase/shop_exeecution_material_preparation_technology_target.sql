SELECT
    bill."id",
    bill."修改时间"
FROM
    ods.shop_exeecution_material_preparation_technology bill