SELECT
    bill."id",
    bill."操作时间"
FROM
    ods.technological_process_flow bill