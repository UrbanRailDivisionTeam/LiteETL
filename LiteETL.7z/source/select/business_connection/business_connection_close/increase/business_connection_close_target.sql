SELECT
       bill."id",
       bill."任务状态"
FROM
       ods.business_connection_close bill