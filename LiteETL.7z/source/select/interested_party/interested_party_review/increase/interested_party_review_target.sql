SELECT
    bill."id",
    bill."修改时间"
FROM
    ods.interested_party_review bill