SELECT
    bill.Fid AS "id",
    bill.fmodifytime as "修改时间"
FROM
    crrc_secd.tk_crrc_xgfgl bill