SELECT
    bill.id,
    bill."提交时间"
FROM ods.interested_party_entry bill