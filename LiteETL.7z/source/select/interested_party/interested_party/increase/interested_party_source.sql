SELECT
    id,
    "submitTime" AS "提交时间"
FROM safeformhead