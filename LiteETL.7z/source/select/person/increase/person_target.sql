SELECT
    bill."id",
    bill."员工编码",
    bill."上次更新时间"
FROM
    ods.person bill